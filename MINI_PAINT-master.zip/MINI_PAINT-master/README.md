# JAVAProject
miniPaint

#NetBeans_Project

This is similar to Microsoft Paint with limited features as follows 1.Draw_Line 2.Draw_Circle 3.Draw_Oval 4.Draw_Rectangle 5.Free_Draw(like Pencil) 6.Colour Filled Draw of Oval,Circle,Rectangle 7.Colour chooser 8.Undo 9.Redo 10.File options(New,Open,Save,Save as) 11.StrokeSize selector

This Application uses: a.Stack Data Structure to implement undo and redo b.MouseAdapter class implementing MouseListener and MouseMotionListener c.MouseListener(MousePressed and MouseReleased methods) d.MouseMotionListener(MouseMoved and MouseDragged methods) e.Swing Controls(JColorChooser,JLabel,JComboBox,JToggleButton), Swing Container(JPanel), Swing Menu(MenuBar) f.Graphics2D class g.JFileChooser class

![paintvideo](https://user-images.githubusercontent.com/26309884/28127186-5f393ae8-6749-11e7-9513-aee011a6b049.gif)
